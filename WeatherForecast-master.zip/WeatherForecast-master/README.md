# WeatherForecast
<p>This single-view application uses :</p>
 <ul>
  <li>Alamofire pod library to parse Json obtained from openweathermap API</li>
  <li>Auto Layout</li>
  <li>Components designed in Sketch</li>
  <li>CLLocation Manager to fetch the present coordinates</li>
 </ul>
<p>Main Weather Forecast Screen</p>
<img src="Screenshot/MainScreen.png" width = "300" height = "614"/>
<p>Device Comparison and Location request Authorisation Screen</p>
<img src="Screenshot/DeviceComparison.png" width = "600" height = "614" />
